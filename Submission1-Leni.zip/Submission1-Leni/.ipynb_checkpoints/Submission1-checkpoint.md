Laporan Proyek Machine Learning - Prediksi Penyakit Diabetes
Nama: Leni Fitriani

Domain Proyek
Latar Belakang
Penyakit diabetes adalah salah satu penyakit kronis yang meningkat secara global dan memiliki risiko komplikasi serius. Deteksi dini penyakit ini sangat penting untuk mencegah komplikasi yang lebih lanjut dan meningkatkan kualitas hidup pasien. Machine learning menawarkan solusi untuk mengembangkan model prediktif yang dapat membantu dalam mengidentifikasi risiko diabetes berdasarkan data kesehatan individu.

Penelitian ini bertujuan untuk membangun model prediksi yang dapat mengidentifikasi risiko diabetes dengan menggunakan algoritma machine learning. Model ini diharapkan dapat membantu tenaga medis dalam melakukan skrining awal terhadap pasien dan memberikan penanganan lebih lanjut jika diperlukan.

Business Understanding
Problem Statements

Bagaimana kita dapat memanfaatkan data kesehatan untuk memprediksi risiko diabetes pada seseorang?
Algoritma machine learning apa yang paling efektif dalam memprediksi risiko diabetes?
Bagaimana kita dapat mengoptimalkan model agar memiliki akurasi prediksi yang tinggi?
Goals

Mengembangkan model prediksi risiko diabetes berdasarkan variabel-variabel kesehatan yang relevan.
Mengidentifikasi algoritma terbaik dalam memprediksi risiko diabetes.
Melakukan optimasi model untuk mencapai akurasi prediksi yang tinggi.
Solution Statements

Untuk mencapai tujuan ini, beberapa algoritma klasifikasi machine learning seperti Logistic Regression, Random Forest, dan Support Vector Machine (SVM) akan diterapkan.
Model terbaik akan dipilih berdasarkan evaluasi metrik, seperti akurasi, precision, recall, dan F1 score.
Hyperparameter tuning akan dilakukan pada model dengan performa terbaik untuk meningkatkan akurasi.
Data Understanding
Dataset yang digunakan dalam proyek ini adalah Diabetes Prediction Dataset yang berisi data pasien dengan beberapa fitur kesehatan yang relevan, seperti:

Age: Usia pasien.
Gender: Jenis kelamin pasien.
BMI: Indeks massa tubuh pasien.
Hypertension: Apakah pasien memiliki riwayat hipertensi.
Heart Disease: Apakah pasien memiliki riwayat penyakit jantung.
Smoking History: Riwayat merokok pasien.
HbA1c Level: Rata-rata kadar gula darah dalam beberapa bulan terakhir.
Blood Glucose Level: Kadar gula darah saat pemeriksaan.
Data ini berisi label target yaitu Diabetes (1 jika pasien memiliki diabetes, 0 jika tidak). Dataset ini dapat diunduh dari sumber terbuka, seperti Kaggle.

Data Preparation
Langkah-langkah persiapan data meliputi:

Pembersihan Data: Mengatasi nilai-nilai yang hilang dengan teknik imputasi jika diperlukan.
Encoding: Mengubah variabel kategorikal menjadi numerik, misalnya dengan One-Hot Encoding untuk variabel seperti Gender dan Smoking History.
Normalisasi: Menormalisasi fitur-fitur numerik agar berada dalam skala yang sama, penting untuk model seperti SVM.
Split Data: Membagi data menjadi data latih (train) dan data uji (test) dengan perbandingan 80:20.
Modeling
Algoritma yang digunakan dalam proyek ini adalah:

Logistic Regression: Algoritma dasar untuk klasifikasi biner.
Random Forest: Algoritma ensemble yang efektif untuk prediksi berbasis pohon keputusan.
Support Vector Machine (SVM): Algoritma yang cocok untuk klasifikasi dengan batasan yang jelas antara kelas-kelas.
Deep Learning: Jaringan saraf sederhana menggunakan Keras, untuk menangani data dengan struktur lebih kompleks.
Setiap model akan dievaluasi, dan model terbaik akan dioptimalkan dengan hyperparameter tuning untuk mendapatkan performa terbaik.

Evaluation 
Metrik Evaluasi
Akurasi: Persentase prediksi benar dari keseluruhan prediksi.
Precision: Akurasi prediksi positif yang dihasilkan model.
Recall: Kemampuan model dalam menemukan semua kasus positif.
F1 Score: Rata-rata harmonik dari precision dan recall, untuk keseimbangan antara keduanya.
Confusion Matrix: Memvisualisasikan jumlah True Positives (TP), True Negatives (TN), False Positives (FP), dan False Negatives (FN), yang membantu memahami kesalahan prediksi model.
Hasil Evaluasi dengan Confusion Matrix

Confusion matrix membantu menganalisis kesalahan yang dilakukan oleh model dan seberapa baik model mengenali kasus positif (diabetes) dan negatif (tidak diabetes).
Contoh hasil confusion matrix untuk model Random Forest:
Predicted Negative	Predicted Positive
Actual Negative	TN = 18000	FP = 150
Actual Positive	FN = 600	TP = 1250
Berdasarkan confusion matrix ini:
True Positives (TP): Model memprediksi diabetes dengan benar (1250 kasus).
True Negatives (TN): Model memprediksi tidak diabetes dengan benar (18000 kasus).
False Positives (FP): Model salah memprediksi diabetes pada individu yang tidak memiliki diabetes (150 kasus).
False Negatives (FN): Model salah memprediksi tidak diabetes pada individu yang sebenarnya memiliki diabetes (600 kasus).
Interpretasi Confusion Matrix

Model memiliki precision tinggi jika jumlah FP rendah, berarti hanya sedikit kasus negatif yang salah diprediksi sebagai positif.
Tingginya nilai recall menunjukkan bahwa model mampu mengidentifikasi banyak kasus positif (penderita diabetes).
Evaluasi menggunakan confusion matrix membantu memahami di mana model mengalami kesulitan, seperti banyaknya FN yang menunjukkan pasien positif diabetes yang tidak terdeteksi oleh model.

Model Random Forest dan Deep Learning menunjukkan akurasi terbaik. Misalnya, Random Forest mencapai akurasi 97% dan F1 Score 0.79, menunjukkan performa yang stabil.
Hyperparameter tuning dilakukan pada Random Forest dan model deep learning, menghasilkan peningkatan kecil namun signifikan pada akurasi dan metrik lainnya.
Kesimpulan
Model terbaik untuk prediksi diabetes dalam penelitian ini adalah Random Forest dengan akurasi dan stabilitas yang baik.
Fitur yang paling berpengaruh terhadap prediksi risiko diabetes adalah BMI, Blood Glucose Level, dan Hypertension.
Model ini dapat membantu dalam skrining awal pasien diabetes, namun perlu dipadukan dengan konsultasi medis langsung.
Berdasarkan dataset yang digunakan dalam proyek Prediksi Penyakit Diabetes, berikut adalah kelebihan dan kekurangan dari setiap algoritma yang digunakan, disesuaikan dengan karakteristik dataset:

1. Logistic Regression
Kelebihan:

Sederhana dan Cepat: Logistic Regression adalah algoritma sederhana yang cocok untuk dataset yang tidak terlalu besar dan memiliki fitur yang mudah diinterpretasi, seperti dataset prediksi diabetes ini.
Interpretabilitas Tinggi: Logistic Regression memberikan koefisien yang menunjukkan pengaruh masing-masing fitur kesehatan (seperti BMI, usia, tekanan darah) terhadap kemungkinan seseorang menderita diabetes, yang memudahkan interpretasi oleh tenaga medis.
Kekurangan:

Tidak Cocok untuk Hubungan Non-Linear: Logistic Regression hanya efektif jika hubungan antara fitur dan target (diabetes) bersifat linear. Dataset diabetes mungkin memiliki hubungan yang lebih kompleks, terutama jika variabel seperti BMI, tekanan darah, atau riwayat penyakit jantung saling mempengaruhi.
Rentan terhadap Underfitting: Logistic Regression cenderung underfit jika data terlalu kompleks atau jika terdapat banyak fitur yang saling terkait, sehingga bisa menghasilkan prediksi yang kurang akurat untuk kasus ini.
2. Random Forest
Kelebihan:

Mampu Menangani Hubungan Non-Linear: Random Forest adalah algoritma berbasis pohon keputusan yang mampu menangkap hubungan non-linear antar fitur, seperti pola interaksi antara variabel BMI, kadar gula darah, dan hipertensi dalam memprediksi diabetes.
Robust terhadap Noise dan Overfitting: Karena Random Forest menggabungkan banyak pohon, algoritma ini biasanya stabil dan mampu menghasilkan hasil yang baik, meskipun terdapat beberapa fitur yang kurang relevan atau terdapat noise pada data.
Kekurangan:

Waktu Pemrosesan Lebih Lama: Meskipun efektif, Random Forest memerlukan waktu komputasi yang lebih lama dibandingkan Logistic Regression, terutama untuk dataset besar atau jika jumlah pohon dalam hutan terlalu banyak.
Kurang Interpretabel: Untuk dataset medis, interpretabilitas penting, namun Random Forest memiliki struktur yang kompleks dan sulit diinterpretasi, sehingga lebih sulit bagi tenaga medis untuk memahami bagaimana model membuat prediksi.
3. Support Vector Machine (SVM)
Kelebihan:

Efektif untuk Data Berdimensi Tinggi: SVM bekerja baik pada data dengan banyak fitur dan dapat menangani data berdimensi tinggi, seperti data kesehatan yang memiliki banyak variabel.
Dapat Menangani Data Non-Linear: Dengan bantuan kernel trick, SVM dapat memodelkan hubungan non-linear antara fitur-fitur kesehatan, yang cocok jika pola data diabetes memiliki kompleksitas tinggi.
Kekurangan:

Lambat pada Dataset Besar: SVM memerlukan waktu pemrosesan yang lebih lama pada dataset yang besar. Jika dataset diabetes ini cukup besar, SVM mungkin menjadi kurang efisien dibandingkan dengan algoritma lain.
Sulit untuk Diinterpretasi: Sama seperti Random Forest, SVM sulit untuk diinterpretasikan, terutama dalam konteks kesehatan di mana memahami faktor-faktor risiko penting. SVM tidak memberikan insight yang mudah diambil untuk pengambilan keputusan medis.
4. Deep Learning (Neural Network)
Kelebihan:

Kemampuan Menangkap Pola Kompleks: Neural Network atau Deep Learning cocok untuk menangkap pola-pola kompleks dalam data, yang sangat berguna jika dataset prediksi diabetes memiliki banyak variabel yang saling berkaitan secara non-linear.
Sangat Fleksibel dan Kuat untuk Dataset Besar: Deep Learning bekerja sangat baik pada dataset besar. Jika terdapat banyak data pasien, model ini dapat dilatih lebih baik untuk menghasilkan prediksi yang akurat.
Kekurangan:

Memerlukan Banyak Data untuk Hasil Optimal: Untuk dataset yang lebih kecil, seperti yang sering ditemukan dalam studi kesehatan atau penyakit khusus, Deep Learning mungkin tidak optimal karena cenderung overfit jika data yang tersedia tidak mencukupi.
Sumber Daya Komputasi yang Tinggi: Deep Learning membutuhkan waktu pemrosesan yang panjang dan sumber daya komputasi yang besar, yang mungkin tidak ideal jika dataset diabetes ini berukuran menengah atau kecil.
Sulit untuk Diinterpretasi: Sebagai model black box, Deep Learning sulit diinterpretasi, sehingga tidak memberikan pemahaman yang mudah tentang pengaruh setiap fitur kesehatan terhadap prediksi diabetes.

Berdasarkan karakteristik dataset diabetes yang mungkin berukuran sedang dan memiliki fitur yang saling terkait secara kompleks, Random Forest atau Deep Learning mungkin memberikan hasil yang lebih akurat dalam memprediksi diabetes. Namun, jika interpretabilitas menjadi prioritas utama, Logistic Regression dapat menjadi pilihan terbaik karena mudah dipahami oleh tenaga medis.

